<?php

namespace TEC\Common\Contracts;

use TEC\Common\lucatume\DI52\ServiceProvider as DI52_Service_Provider;

abstract class Service_Provider extends DI52_Service_Provider  {
    // Intentionally empty.
}
