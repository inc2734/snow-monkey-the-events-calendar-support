<?php
/**
 * @deprecated 6.3.0
 */
namespace Tribe\Admin\Notice\Marketing;

_deprecated_file( __FILE__, '6.3.0', 'No Replacement' );

/**
 * Class Black_Friday
 *
 * @since 4.14.2
 * @deprecated 6.3.0
 *
 * @package Tribe\Admin\Notice\Marketing
 */
class Black_Friday {
	public function __call( $name, $arguments ) {
		_deprecated_function( __METHOD__, '6.3.0', 'No replacement.' );
	}

	public static function __callStatic( $name, $arguments ) {
		_deprecated_function( __METHOD__, '6.3.0', 'No replacement.' );
	}
}
