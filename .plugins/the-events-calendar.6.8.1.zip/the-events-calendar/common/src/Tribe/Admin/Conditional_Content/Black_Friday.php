<?php
/**
 * @deprecated 6.3.0
 */
namespace Tribe\Admin\Conditional_Content;

_deprecated_file( __FILE__, '6.3.0', '\TEC\Common\Admin\Conditional_Content\Black_Friday', 'This file is deprecated in favor of new Namespace' );

/**
 * Class Black_Friday.
 *
 * @since       4.14.7
 * @deprecated 6.3.0
 *
 * @package     Tribe\Admin\Conditional_Content
 */
class Black_Friday {
	public function __call( $name, $arguments ) {
		_deprecated_function( __METHOD__, '6.3.0', 'No replacement.' );
	}

	public static function __callStatic( $name, $arguments ) {
		_deprecated_function( __METHOD__, '6.3.0', 'No replacement.' );
	}
}
