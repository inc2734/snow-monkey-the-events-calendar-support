<?php
/**
 * @deprecated 6.3.0
 */
namespace Tribe\Admin\Conditional_Content;

_deprecated_file( __FILE__, '6.3.0', 'No Replacement' );

/**
 * Class Service_Provider
 *
 * @since   4.14.7
 * @deprecated 6.3.0
 *
 * @package Tribe\Admin\Conditional_Content
 */
class Service_Provider {
	public function __call( $name, $arguments ) {
		_deprecated_function( __METHOD__, '6.3.0', 'No replacement.' );
	}

	public static function __callStatic( $name, $arguments ) {
		_deprecated_function( __METHOD__, '6.3.0', 'No replacement.' );
	}
}
